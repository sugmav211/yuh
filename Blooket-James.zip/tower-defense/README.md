# tower-defense

This cheat only works in tower defense game mode!

# changeGameRound.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/changeGameRound.js").then((res) => res.text().then((t) => eval(t)))
```

# clearEnemies.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/clearEnemies.js").then((res) => res.text().then((t) => eval(t)))
```

# getCash.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/tower-defense/getCash.js").then((res) => res.text().then((t) => eval(t)))
```
