# py

## How-To

- Getting a compiler
- Running the code
- Understanding how to use

## Compiling

- Use Replit or install the latest Python release

## Running

- Windows: type `cmd` and enter "python yourfilepath.py"
- Linux: open powershell and enter "python yourfilepath.py"
