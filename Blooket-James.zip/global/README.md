# global

All these cheats in the folder can be used outside games

# addTokens.js

note: **This cheat also includes adding max xp for the day**

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/addTokens.js").then((res) => res.text().then((t) => eval(t)))
```

# bypassRandomName.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/bypassRandomName.js").then((res) => res.text().then((t) => eval(t)))
```

# floodGames.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/floodGames.js").then((res) => res.text().then((t) => eval(t)))
```

# getAllBlooksInGame.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/getAllBlooksInGame.js").then((res) => res.text().then((t) => eval(t)))
```

# getEveryAnswerCorrect.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/getEveryAnswerCorrect.js").then((res) => res.text().then((t) => eval(t)))
```

# spamOpenBoxes.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/spamOpenBoxes.js").then((res) => res.text().then((t) => eval(t)))
```

# sellDupeBlooks.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/global/sellDupeBlooks.js").then((res) => res.text().then((t) => eval(t)))
```
