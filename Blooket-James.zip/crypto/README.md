# crypto

This cheat only works in crypto hack game mode!

# getCrypto.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crypto/getCrypto.js").then((res) => res.text().then((t) => eval(t)))
```

# getOtherUsersPassword.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crypto/getOtherUsersPassword.js").then((res) => res.text().then((t) => eval(t)))
```
