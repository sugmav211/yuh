# crazy-kingdom

This cheat only works in crazy kingdom gamemode!

# ChoiceESP.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/ChoiceESP.js").then((res) => res.text().then((t) => eval(t)))
```

# MaxResources.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/MaxResources.js").then((res) => res.text().then((t) => eval(t)))
```

# NoTaxes.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/NoTaxes.js").then((res) => res.text().then((t) => eval(t)))
```

# SetGuests.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/SetGuests.js").then((res) => res.text().then((t) => eval(t)))
```

# SkipGuests.js

Open console (ctrl + shift + j) and paste the following:
```js
fetch("https://raw.githubusercontent.com/glixzzy/blooket-hack/main/crazy-kingdom/SkipGuest.js").then((res) => res.text().then((t) => eval(t)))
```
